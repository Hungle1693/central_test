import SendKeys

class CustomPython:

    def send_enter_key():
        """
        Sends ENTER key to application
        Works only in Windows
        """
        SendKeys.SendKeys("{ENTER}")